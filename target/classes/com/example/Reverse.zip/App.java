package com.example;

/**
 * Multiply Sum
 *
 */
public class App {
    public static void main(String[] args) {

        // Check if number is a prime number
        System.out.println("abc123!!! => " + reverseStringKeepFirstCharacter("abc123!!!"));
        System.out.println("fat!cat => " + reverseStringKeepFirstCharacter("fat!cat"));
    }

    public static String reverseStringKeepFirstCharacter(String str) {

        StringBuilder sb = new StringBuilder();
        sb.append(str.charAt(0));
        for (int i = str.length() - 1; i > 0; i--) {
            sb.append(str.charAt(i));
        }
        return sb.toString();
    }
}
