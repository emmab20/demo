package com.example;

/**
 * Multiply Sum
 *
 */
public class App {
    public static void main(String[] args) {
        int array1[] = { 3, 2, 1 };
        int array2[] = { 4, 5 };
        System.out.println("Array1: " + array1);
        System.out.println("Array2: " + array2);
        System.out.println("Sum multiplied: " + multiplySum(array1, array2));
    }

    public static int multiplySum(int[] arr1, int[] arr2) {
        int sum1 = 0;
        int sum2 = 0;
        for (int i = 0; i < arr1.length; i++) {
            sum1 += arr1[i];
        }
        for (int i = 0; i < arr2.length; i++) {
            sum2 += arr2[i];
        }
        return sum1 * sum2;
    }
}
