package com.example;

/**
 * Multiply Sum
 *
 */
public class App {
    public static void main(String[] args) {

        // Check if number is a prime number
        System.out.println("10 is a prime number: " + isPrime(10));
        System.out.println("32 is a prime number: " + isPrime(32));
        System.out.println("11 is a prime number: " + isPrime(11));
    }

    public static boolean isPrime(int number) {
        // checking if number is divisible by 2
        if (number % 2 == 0)
            return false;
        // if not, then check the odd numbers
        for (int i = 3; i * i <= number; i += 2) {
            if (number % i == 0)
                return false;
        }
        return true;
    }
}
