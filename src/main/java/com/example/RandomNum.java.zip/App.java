package com.example;

/**
 * Return random number from array
 *
 */
import java.util.Random;

public class App {
    public static void main(String[] args) {
        // Create an array of integers
        int[] numbers = { 1, 2, 3, 4, 5 };

        // Create a Random object
        Random rand = new Random();

        // Generate a random index within the array
        int index = rand.nextInt(numbers.length);

        // Print the element at the random index
        System.out.println(numbers[index]);
    }
}
