package com.example;

import java.util.Arrays;

class Main {
    public static void main(String[] args) {

        // Initialize the array
        int[] nums = { 1, 2, 2, 3, 3, 3, 4, 5, 5 };

        // Create new array that removes duplicates.
        int[] newNums = removeDuplicates(nums);

        // Display new array without duplicates.
        System.out.println(Arrays.toString(newNums));
    }

    // Array must be sorted or it won't work properly.
    public static int[] removeDuplicates(int[] nums) {

        // Quit if the array is empty
        if (nums.length == 0)
            return nums;

        int i = 0;
        for (int j = 1; j < nums.length; j++) {
            if (nums[j] != nums[i]) {
                i++;
                nums[i] = nums[j];
            }
        }
        return Arrays.copyOf(nums, i + 1);
    }

}